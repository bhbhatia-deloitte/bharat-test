export const environment = {
  production: true,
  // api_url: 'http://159.89.176.66:3000',// UAT server
  api_url: "http://198.211.104.193:3000", // Dev Server
  // api_url: "https://purecaretest1.xyz", // New UAT Server
  // api_url: "https://api.purecare.com.hk", // Client Production server
  // api_url: "https://api.purecaretest1.xyz", // Client Test server
};
